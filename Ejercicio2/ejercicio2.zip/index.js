
const libros = [ "Martin Fierro De José Hernandez - Grupo Clasa",
                 "José Hernández", "2016", 
                 "https://www.mercadolibre.com.ar/libro-martin-fierro-de-jose-hernandez-grupo-clasa/p/MLA19941643?pdp_filters=item_id:MLA1282493965#is_advertising=true&searchVariation=MLA19941643&position=1&search_layout=stack&type=pad&tracking_id=321b07ce-6908-4f02-968b-25fa7cd31d26&is_advertising=true&ad_domain=VQCATCORE_LST&ad_position=1&ad_click_id=YTQ5N2Y0OTMtNDI4Ny00NDYwLWE3YjYtNGJkZTAxOGE2MTY4"];

const datosPersonales = ["Oscar",
                        50,
                        true,
                        "march 25 2020",
                        libros,

]

